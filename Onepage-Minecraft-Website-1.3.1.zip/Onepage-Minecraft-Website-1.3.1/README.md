# Onepage-Minecraft-Server-Website-
A simple onepage website for you minecraft server.

So, if you're wanting to use this template for your website, you'll need a webserver/hosting.

You're not allowed to 'steal' this template and post it ANYWHERE else.
The offical links for this template are:
  https://www.spigotmc.org/resources/onepage-minecraft-server-website.56408/
  https://github.com/TheSparkPlays/Onepage-Minecraft-Server-Website-
  
And for the live demo:
  https://www.rickklaasboer.online/demo/onepage-template/

That's basically it for now.

Good luck with setting up your website!
